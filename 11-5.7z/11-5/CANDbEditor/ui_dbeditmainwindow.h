/********************************************************************************
** Form generated from reading UI file 'dbeditmainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DBEDITMAINWINDOW_H
#define UI_DBEDITMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionNewdatabase;
    QAction *actionOpendatabase;
    QAction *actionSavedatabase;
    QAction *actionSavedatabaseas;
    QAction *actionQuit;
    QAction *actionEdit;
    QAction *actionRemove;
    QAction *actionCopy;
    QAction *actionPaste;
    QAction *actionSetting;
    QAction *actionAbout;
    QWidget *centralwidget;
    QMenuBar *menubar;
    QMenu *menu_File;
    QMenu *menu_Edit;
    QMenu *menu_Option;
    QMenu *menu_Help;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(800, 600);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        actionNewdatabase = new QAction(MainWindow);
        actionNewdatabase->setObjectName(QStringLiteral("actionNewdatabase"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/new.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNewdatabase->setIcon(icon1);
        actionNewdatabase->setShortcutContext(Qt::WindowShortcut);
        actionOpendatabase = new QAction(MainWindow);
        actionOpendatabase->setObjectName(QStringLiteral("actionOpendatabase"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOpendatabase->setIcon(icon2);
        actionSavedatabase = new QAction(MainWindow);
        actionSavedatabase->setObjectName(QStringLiteral("actionSavedatabase"));
        actionSavedatabase->setEnabled(false);
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/icons/save.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSavedatabase->setIcon(icon3);
        actionSavedatabaseas = new QAction(MainWindow);
        actionSavedatabaseas->setObjectName(QStringLiteral("actionSavedatabaseas"));
        actionSavedatabaseas->setEnabled(false);
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/icons/saveas.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSavedatabaseas->setIcon(icon4);
        actionQuit = new QAction(MainWindow);
        actionQuit->setObjectName(QStringLiteral("actionQuit"));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/icons/quit.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionQuit->setIcon(icon5);
        actionQuit->setShortcutContext(Qt::ApplicationShortcut);
        actionQuit->setMenuRole(QAction::QuitRole);
        actionEdit = new QAction(MainWindow);
        actionEdit->setObjectName(QStringLiteral("actionEdit"));
        actionEdit->setEnabled(false);
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/icons/edit.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionEdit->setIcon(icon6);
        actionRemove = new QAction(MainWindow);
        actionRemove->setObjectName(QStringLiteral("actionRemove"));
        actionRemove->setEnabled(false);
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/icons/remove.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRemove->setIcon(icon7);
        actionCopy = new QAction(MainWindow);
        actionCopy->setObjectName(QStringLiteral("actionCopy"));
        actionCopy->setEnabled(false);
        QIcon icon8;
        icon8.addFile(QStringLiteral(":/icons/copy.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCopy->setIcon(icon8);
        actionPaste = new QAction(MainWindow);
        actionPaste->setObjectName(QStringLiteral("actionPaste"));
        actionPaste->setEnabled(false);
        QIcon icon9;
        icon9.addFile(QStringLiteral(":/icons/paste.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPaste->setIcon(icon9);
        actionSetting = new QAction(MainWindow);
        actionSetting->setObjectName(QStringLiteral("actionSetting"));
        QIcon icon10;
        icon10.addFile(QStringLiteral(":/icons/setting.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSetting->setIcon(icon10);
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        QIcon icon11;
        icon11.addFile(QStringLiteral(":/icons/about.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAbout->setIcon(icon11);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 25));
        menu_File = new QMenu(menubar);
        menu_File->setObjectName(QStringLiteral("menu_File"));
        menu_Edit = new QMenu(menubar);
        menu_Edit->setObjectName(QStringLiteral("menu_Edit"));
        menu_Option = new QMenu(menubar);
        menu_Option->setObjectName(QStringLiteral("menu_Option"));
        menu_Help = new QMenu(menubar);
        menu_Help->setObjectName(QStringLiteral("menu_Help"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menu_File->menuAction());
        menubar->addAction(menu_Edit->menuAction());
        menubar->addAction(menu_Option->menuAction());
        menubar->addAction(menu_Help->menuAction());
        menu_File->addAction(actionNewdatabase);
        menu_File->addAction(actionOpendatabase);
        menu_File->addSeparator();
        menu_File->addAction(actionSavedatabase);
        menu_File->addAction(actionSavedatabaseas);
        menu_File->addSeparator();
        menu_File->addAction(actionQuit);
        menu_Edit->addAction(actionEdit);
        menu_Edit->addSeparator();
        menu_Edit->addAction(actionRemove);
        menu_Edit->addSeparator();
        menu_Edit->addAction(actionCopy);
        menu_Edit->addAction(actionPaste);
        menu_Option->addAction(actionSetting);
        menu_Help->addAction(actionAbout);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "CANDb Editor", Q_NULLPTR));
        actionNewdatabase->setText(QApplication::translate("MainWindow", "&New database", Q_NULLPTR));
        actionNewdatabase->setShortcut(QApplication::translate("MainWindow", "Ctrl+N", Q_NULLPTR));
        actionOpendatabase->setText(QApplication::translate("MainWindow", "Open database", Q_NULLPTR));
        actionOpendatabase->setShortcut(QApplication::translate("MainWindow", "Ctrl+O", Q_NULLPTR));
        actionSavedatabase->setText(QApplication::translate("MainWindow", "Save database", Q_NULLPTR));
        actionSavedatabase->setShortcut(QApplication::translate("MainWindow", "Ctrl+S", Q_NULLPTR));
        actionSavedatabaseas->setText(QApplication::translate("MainWindow", "Save database as", Q_NULLPTR));
        actionSavedatabaseas->setShortcut(QApplication::translate("MainWindow", "Ctrl+Shift+S", Q_NULLPTR));
        actionQuit->setText(QApplication::translate("MainWindow", "Quit", Q_NULLPTR));
        actionQuit->setShortcut(QApplication::translate("MainWindow", "Ctrl+Q", Q_NULLPTR));
        actionEdit->setText(QApplication::translate("MainWindow", "Edit", Q_NULLPTR));
        actionEdit->setShortcut(QApplication::translate("MainWindow", "Enter", Q_NULLPTR));
        actionRemove->setText(QApplication::translate("MainWindow", "Remove", Q_NULLPTR));
        actionRemove->setShortcut(QApplication::translate("MainWindow", "Del", Q_NULLPTR));
        actionCopy->setText(QApplication::translate("MainWindow", "Copy", Q_NULLPTR));
        actionCopy->setShortcut(QApplication::translate("MainWindow", "Ctrl+C", Q_NULLPTR));
        actionPaste->setText(QApplication::translate("MainWindow", "Paste", Q_NULLPTR));
        actionPaste->setShortcut(QApplication::translate("MainWindow", "Ctrl+V", Q_NULLPTR));
        actionSetting->setText(QApplication::translate("MainWindow", "Setting", Q_NULLPTR));
        actionAbout->setText(QApplication::translate("MainWindow", "About CANDb Editor", Q_NULLPTR));
        actionAbout->setShortcut(QApplication::translate("MainWindow", "F11", Q_NULLPTR));
        menu_File->setTitle(QApplication::translate("MainWindow", "&File", Q_NULLPTR));
        menu_Edit->setTitle(QApplication::translate("MainWindow", "&Edit", Q_NULLPTR));
        menu_Option->setTitle(QApplication::translate("MainWindow", "&Option", Q_NULLPTR));
        menu_Help->setTitle(QApplication::translate("MainWindow", "&Help", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DBEDITMAINWINDOW_H
