#include "addsigdialog.h"
#include <QGridLayout>

addSigDialog::addSigDialog(const MainDbEditor *editor, QWidget *parent): QDialog(parent)
{
       signal = new QTableWidget(10,4,0);
       QStringList m1_TableHeader;
       m1_TableHeader<<"Name"<< "Length[Bit]"<<"Byte Order"<<"Value Type";
        signal->setHorizontalHeaderLabels(m1_TableHeader);
        signal->setSelectionBehavior(QAbstractItemView::SelectRows);
        QModelIndex messIndex = const_cast<MainDbEditor*>(editor)->getTreeWidget()->currentIndex();
        int k=0;
        for(int i=0;i<const_cast<MainDbEditor*>(editor)->getMainDbManager()->getSignalsList().size();i++){
    CANSignal *sig =const_cast<MainDbEditor*>(editor)->getMainDbManager()->getSignalsList().at(i);
    bool checkSigInMess = false;
//    for(int j=0; j<const_cast<MainDbEditor*>(editor)->getMainDbManager()->getMessagesList().at(messIndex.row())->m_Signals.size();j++){
//    if(compareSignal(const_cast<MainDbEditor*>(editor)->getMainDbManager()->getSignalsList().at(i),
//    const_cast<MainDbEditor*>(editor)->getMainDbManager()->getMessagesList().at(messIndex.row())->m_Signals.at(j).m_Signal))
//        checkSigInMess = true;
//    }


    if(checkSigInMess==false){
                    signal->setItem(k,0,new QTableWidgetItem(sig->m_Name));
                    signal->setItem(k,1,new QTableWidgetItem(QString::number(sig->m_Length)));
                    if(sig->m_ByteOrder == 1)
                    signal->setItem(k,2,new QTableWidgetItem("Motorola"));
                    else
                    signal->setItem(k,2,new QTableWidgetItem("Intel"));
                    if(sig->m_ValueType == 0)
                    signal->setItem(k,3,new QTableWidgetItem("Signed"));
                    else if(sig->m_ValueType == 1)
                    signal->setItem(k,3,new QTableWidgetItem("Unsigned"));
                    else if(sig->m_ValueType == 2)
                    signal->setItem(k,3,new QTableWidgetItem("Float"));
                    else
                    signal->setItem(k,3,new QTableWidgetItem("Double"));
                    k++;

    }
                }

        signal->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
        signal->verticalHeader()->setVisible(false);
        signal->setShowGrid(false);
         addButt = new QPushButton(tr("OK"));
         canccelButt  = new QPushButton(tr("Cancel"));
        QGridLayout *mainLayout = new QGridLayout;
        mainLayout->addWidget(signal,0,0,10,8);
        mainLayout->addWidget(addButt,10,0,1,1);
        mainLayout->addWidget(canccelButt,10,1,1,1);
        //mainLayout->addStretch(1);
        setLayout(mainLayout);
        setWindowTitle("Add Signal Editor");
        connect(addButt,SIGNAL(clicked()),this,SLOT(clickAddButton()));
        connect(canccelButt,SIGNAL(clicked()),this,SLOT(clickCancelButton()));
}

addSigDialog::clickAddButton()
{
    //int row =this->signal->currentIndex().row();
    //int selectedRowCount = signal->selectedItems().size()/signal->columnCount();
    QList<int> listRow;
    for(int i=0;i<signal->selectedItems().size();i+=signal->columnCount()){
        listRow<<signal->selectedItems().at(i)->row();
    }
QVector<CANSignal*> listAddSig;
for(int i=0;i<listRow.size();i++){
CANSignal *sig = new CANSignal;
sig->m_Name =this->signal->item(listRow.at(i),0)->text();
sig->m_Length= this->signal->item(listRow.at(i),1)->text().toInt();
if(this->signal->item(listRow.at(i),2)->text()=="Motorola"){
    sig->m_ByteOrder= E_CANByteOrder_Motorola;
}else{
    sig->m_ByteOrder= E_CANByteOrder_Intel;
}

if(this->signal->item(listRow.at(i),3)->text()=="Signed"){
    sig->m_ValueType= E_CANSignalSign_Signed;
}else if(this->signal->item(listRow.at(i),3)->text()=="Unsigned"){
    sig->m_ValueType= E_CANSignalSign_UnSigned;
}else if(this->signal->item(listRow.at(i),3)->text()=="Float"){
    sig->m_ValueType= E_CANSignalSign_Float;
}else{
    sig->m_ValueType= E_CANSignalSign_Double;
}
listAddSig<<sig;
}
for(int i=0;i<listAddSig.size();i++){
        qDebug()<<"listAddSig = "<<listAddSig.at(i)->m_Name;
}
   // emit addSig2Mess(sig);
        emit addListSig2Mess(listAddSig);
//close();
delete this;
}

addSigDialog::clickCancelButton()
{
//close();
    delete this;
}


