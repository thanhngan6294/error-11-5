#include "dbeditmainwindow.h"
#include <QAction>
#include<QMenu>
#include<QMenuBar>
#include<QMdiArea>
#include<QMdiSubWindow>
#include <QFileDialog>
#include<QDir>
#include<QDebug>
#include <QToolBar>

DbEditMainWindow::DbEditMainWindow(QWidget *parent) :
    QMainWindow(parent),
    m_mainEditor(NULL)
{
    setupUi(this);
    setupMenu();
    setupToolbar();
    this->showMaximized();
}

DbEditMainWindow::~DbEditMainWindow()
{

}

void DbEditMainWindow::closeEvent(QCloseEvent * event)
{
    qDebug()<< "Closed";
    /*Ask for saving dialog*/
    QDialog * askDialog= new QDialog(this,0);
    askDialog->show();
}

void DbEditMainWindow::setupMenu()
{
    // File menu
    connect(actionNewdatabase, SIGNAL(triggered()), this, SLOT(slotCreateNewFile()));

    // &Open database
    connect(actionOpendatabase, SIGNAL(triggered()), this, SLOT(slotOpenFile()));

    connect(actionSavedatabase, SIGNAL(triggered()), this, SLOT(slotSaveFile()));

    // &Save database as
    connect(actionSavedatabaseas, SIGNAL(triggered()), this, SLOT(slotSaveAsFile()));

    // &Exit
    connect(actionQuit, SIGNAL(triggered()), qApp, SLOT(quit()));
}

void DbEditMainWindow::setupToolbar()
{
    QToolBar * toolBar= new QToolBar();
    toolBar->addAction(actionNewdatabase);
    toolBar->addAction(actionOpendatabase);
    toolBar->addSeparator();
    toolBar->addAction(actionSavedatabase);
    toolBar->addAction(actionSavedatabaseas);

    addToolBar(toolBar);
}

void DbEditMainWindow::loadDb(QString & path)
{
    /*Open data base file in new MDI window*/
    QMdiSubWindow * subWin;
    if(m_mainEditor !=NULL){
        delete m_mainEditor;
    }
    m_mainEditor = new MainDbEditor(this,path);
    m_mainEditor->setWindowTitle(path);
    m_mainEditor->showMaximized();
    QMdiArea * mdiArea = new QMdiArea(this);
    setCentralWidget(mdiArea);
    subWin =  mdiArea->addSubWindow(m_mainEditor,0);
    subWin->showMaximized();
    actionSavedatabase->setEnabled(true);
    actionSavedatabaseas->setEnabled(true);
    /*TODO: Load DB file and create treeview, table widget*/
}
void DbEditMainWindow::saveDb(QString &path)
{
    m_mainEditor->getMainDbManager()->saveDbFile(path);
}

void DbEditMainWindow::saveNewDb(QString &path)
{
    if(path.isEmpty()) return;
    QFile file(path);
    file.open(QIODevice::WriteOnly);
    QTextStream out(&file);
    out<<"VERSION \"\"\n\n\n"


             <<"NS_ :\n"
             <<"NS_DESC_\n"
             <<"CM_"
             <<"BA_DEF_\n"
             <<"BA_\n"
             <<"VAL_\n"
             <<"CAT_DEF_\n"
             <<"CAT_\n"
             <<"FILTER\n"
             <<"BA_DEF_DEF_\n"
             <<"EV_DATA_\n"
             <<"ENVVAR_DATA_\n"
             <<"SGTYPE_\n"
             <<"SGTYPE_VAL_\n"
             <<"BA_DEF_SGTYPE_\n"
             <<"BA_SGTYPE_\n"
             <<"SIG_TYPE_REF_\n"
             <<"VAL_TABLE_\n"
             <<"SIG_GROUP_\n"
             <<"SIG_VALTYPE_\n"
             <<"SIGTYPE_VALTYPE_\n"
             <<"BO_TX_BU_\n"
             <<"BA_DEF_REL_\n"
             <<"BA_REL_\n"
            <<"BA_DEF_DEF_REL_\n"
             <<"BU_SG_REL_\n"
             <<"BU_EV_REL_\n"
             <<"BU_BO_REL_\n"
             <<"SG_MUL_VAL_\n\n"

         <<"BS_:\n"
        <<"BO_ 3221225472 VECTOR__INDEPENDENT_SIG_MSG 0 Vector_XXX";
}

void DbEditMainWindow::slotCreateNewFile()
{
    QFileDialog * fileDialog = new QFileDialog(this);
    fileName = QFileDialog::getSaveFileName( fileDialog, tr("Create new database file"), QDir::currentPath(), tr("Database files (*.dbc);;All files (*.*)"), 0);//, QFileDialog::DontUseNativeDialog );
    if(!fileName.isEmpty())
    {
        saveNewDb(fileName);
        loadDb(fileName);
    }
}
void DbEditMainWindow::slotOpenFile()
{
    QFileDialog * fileDialog = new QFileDialog(this);
    fileName = QFileDialog::getSaveFileName( fileDialog, tr("Open database file"), QDir::currentPath(), tr("Database files (*.dbc);;All files (*.*)"), 0);//, QFileDialog::DontUseNativeDialog );
    if(!fileName.isEmpty())
    {
        loadDb(fileName);
    }
}
void DbEditMainWindow::slotSaveFile()
{

        saveDb(fileName);

}
void DbEditMainWindow::slotSaveAsFile()
{
    QFileDialog * fileDialog = new QFileDialog(this);
    QString fileName = QFileDialog::getSaveFileName( fileDialog, tr("Save database as"), QDir::currentPath(), tr("Database files (*.dbc);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );
    if(!fileName.isEmpty())
    {
        //TODO: emit save signal to manager
        saveDb(fileName);
    }
}
