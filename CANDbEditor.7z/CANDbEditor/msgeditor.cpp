/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include <QtWidgets>

#include "msgeditor.h"

MsgEditor::MsgEditor(const MainDbCommonItem *item, const MainDbEditor * editor,QWidget *parent)
    : QDialog(parent)
{
    QString *s= new QString("aaaaa");

    tabWidget = new QTabWidget;

    DeTabMsg = new DefinitionTabMessage(item);
    SignTab = new SignalsTab(editor);
    TransTabMsg = new TransmittersTabMessage(s);
    ReceiTabMsg = new ReceiversTabMessage(s);
    LayTabMsg = new LayoutTabMessage(s);
    atTabMsg = new  AttributesTabMessage(s);
    ComTabMsg = new CommentTabMessage(item->data(4).toString());

    tabWidget->addTab(DeTabMsg, tr("Definition"));
    tabWidget->addTab(SignTab, QIcon(":/icons/signal.png"), tr("Signals"));
    tabWidget->addTab(TransTabMsg, QIcon(":/icons/network.png"), tr("Transmitters"));
    tabWidget->addTab(ReceiTabMsg, QIcon(":/icons/network.png"), tr("Receivers"));
    tabWidget->addTab(LayTabMsg, tr("Layout"));
    tabWidget->addTab(atTabMsg, QIcon(":/icons/edit.png"), tr("Attributes"));
    tabWidget->addTab(ComTabMsg, tr("Comment"));

    buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok
                                     | QDialogButtonBox::Cancel
                                     | QDialogButtonBox::Apply
                                     | QDialogButtonBox::Help);
 QPushButton *applyButton = buttonBox->button(QDialogButtonBox::Apply);
    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
    connect(applyButton, SIGNAL(clicked()), this, SLOT(slotClickApply()));

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(tabWidget);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

    setWindowTitle(("Message '" + item->data(0).toString() + "'"));
}
void MsgEditor::accept()
{
 this->slotClickApply();
  //why cant we use delete this here
//reject();
  delete this;
}

void MsgEditor::reject()
{
    emit cancel();
    delete this;
}

void MsgEditor::slotClickApply()
{
    CANMessage *editedMessage = new CANMessage();
    editedMessage->m_Name=this->DeTabMsg->fileNameEdit->text();
    editedMessage->m_Length=this->DeTabMsg->DLCEdit->text().toInt();
    editedMessage->m_ID=this->DeTabMsg->IDEdit->text().toInt();
    editedMessage->m_IdType=(E_CANMsgIDType)this->DeTabMsg->TypeEdit->currentIndex();

    emit editMessage(editedMessage);
}
DefinitionTabMessage::DefinitionTabMessage(const MainDbCommonItem *item, QWidget *parent)
    : QWidget(parent)
{
    QLabel *fileNameLabel = new QLabel(tr("Name:"));
    fileNameEdit = new QLineEdit(item->data(0).toString());

    QLabel *Type = new QLabel(tr("Type:"));
    TypeEdit = new QComboBox;
    TypeEdit->addItem("Standard");
    TypeEdit->addItem("Extended");

    TypeEdit->setCurrentIndex(item->data(2).toInt());
    QLabel *ID = new QLabel(tr("ID:"));
    IDEdit = new QLineEdit(item->data(1).toString());


    QLabel *DLC = new QLabel(tr("DLC:"));
    DLCEdit = new QSpinBox;
    DLCEdit->setMinimum(0);
    DLCEdit->setMaximum(8);
    DLCEdit->setValue(item->data(3).toInt());

    QLabel *Transmitter = new QLabel(tr("Transmitter:"));
    QComboBox *TransmitterEdit = new QComboBox;
    TransmitterEdit->addItem("ABS");
    TransmitterEdit->setEnabled(false);

    QLabel *TxMethod = new QLabel(tr("Tx Method:"));
    QComboBox *TxMethodEdit = new QComboBox;
    TxMethodEdit->addItem(item->data(2).toString());
    TxMethodEdit->setEnabled(false);

    QLabel *CycleTime = new QLabel(tr("Cycle Time:"));
    QLineEdit *CycleTimeEdit = new QLineEdit(item->data(3).toString());
    CycleTimeEdit->setEnabled(false);

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(fileNameLabel,0,0,1,1);
    mainLayout->addWidget(fileNameEdit,0,1,1,3);
    mainLayout->addWidget(Type,1,0,1,1);
    mainLayout->addWidget(TypeEdit,1,1,1,3);
    mainLayout->addWidget(ID,2,0,1,1);
    mainLayout->addWidget(IDEdit,2,1,1,1);
    mainLayout->addWidget(DLC,2,2,1,1);

    mainLayout->addWidget(DLCEdit,2,3,1,1);
    mainLayout->addWidget(Transmitter,3,0,1,1);
    mainLayout->addWidget(TransmitterEdit,3,1,1,3);
    mainLayout->addWidget(TxMethod,4,0,1,1);
    mainLayout->addWidget(TxMethodEdit,4,1,1,3);
    mainLayout->addWidget(CycleTime,5,0,1,1);
    mainLayout->addWidget(CycleTimeEdit,5,1,1,3);
    setFixedSize(300,300);
    setLayout(mainLayout);

}

SignalsTab::SignalsTab(const MainDbEditor *editor, QWidget *parent)
    : QWidget(parent)
{
    buttonAdd = new QPushButton(tr("Add"));
    buttonRemove = new QPushButton(tr("Remove"));
    buttonView = new QPushButton(tr("View"));
    signal = new QTableWidget(10,7,0);
    m1_TableHeader<<"Signal"<< "Message"<<"Multiplexing/Group"<<"Starbit"<<"Length[Bit]"<<"Byte Order"<<"Value Type";
    signal->setHorizontalHeaderLabels(m1_TableHeader);
    QModelIndex SigIndex = const_cast<MainDbEditor*>(editor)->getTreeWidget()->currentIndex();
    int k=0;


    for(int i=0;i<const_cast<MainDbEditor*>(editor)->getMainDbManager()->getMessagesList().at(SigIndex.row())->m_Signals.size();i++){
        {
CANSignalInMessage sigINMess =const_cast<MainDbEditor*>(editor)->getMainDbManager()->getMessagesList().at(SigIndex.row())->m_Signals.at(i);
                signal->setItem(k,0,new QTableWidgetItem(sigINMess.m_Signal->m_Name));
                signal->setItem(k,1,new QTableWidgetItem(const_cast<MainDbEditor*>(editor)->getMainDbManager()->getMessagesList().at(SigIndex.row())->m_Name));
                signal->setItem(k,2,new QTableWidgetItem("-"));
                signal->setItem(k,3,new QTableWidgetItem(QString::number(sigINMess.m_StartBit)));
                signal->setItem(k,4,new QTableWidgetItem(QString::number(sigINMess.m_Signal->m_Length)));
                if(sigINMess.m_Signal->m_ByteOrder == 1)
                signal->setItem(k,5,new QTableWidgetItem("Motorola"));
                else
                signal->setItem(k,5,new QTableWidgetItem("Intel"));
                if(sigINMess.m_Signal->m_ValueType == 0)
                signal->setItem(k,6,new QTableWidgetItem("Signed"));
                else if(sigINMess.m_Signal->m_ValueType == 1)
                signal->setItem(k,6,new QTableWidgetItem("Unsigned"));
                else if(sigINMess.m_Signal->m_ValueType == 2)
                signal->setItem(k,6,new QTableWidgetItem("Float"));
                else
                signal->setItem(k,6,new QTableWidgetItem("Double"));
                k++;
                qDebug()<<"i= "<<i;
            }
        }
qDebug()<<"aaa";
    signal->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    signal->verticalHeader()->setVisible(false);
    signal->setShowGrid(false);
    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(signal,0,0,10,8);
    mainLayout->addWidget(buttonAdd,10,0,1,1);
    mainLayout->addWidget(buttonRemove,10,1,1,1);
    mainLayout->addWidget(buttonView,10,10,1,1);
    //mainLayout->addStretch(1);
    setLayout(mainLayout);
}

TransmittersTabMessage::TransmittersTabMessage(const QString *s, QWidget *parent)
    : QWidget(parent)
{
    buttonAdd = new QPushButton(tr("Add"));
    buttonRemove = new QPushButton(tr("Remove"));
    buttonView = new QPushButton(tr("View"));


    signal = new QTableWidget(10,2,0);
    signal->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    m1_TableHeader<<"Name"<< "Address";
    signal->setHorizontalHeaderLabels(m1_TableHeader);
    signal->verticalHeader()->setVisible(false);
    signal->setShowGrid(false);

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(signal,0,0,10,8);
    mainLayout->addWidget(buttonAdd,10,0,1,1);
    mainLayout->addWidget(buttonRemove,10,1,1,1);
    mainLayout->addWidget(buttonView,10,10,1,1);
    setLayout(mainLayout);
}

ReceiversTabMessage::ReceiversTabMessage(const QString *s, QWidget *parent)
    : QWidget(parent)
{
    buttonView = new QPushButton(tr("View"));
    QTreeWidget *signal = new QTreeWidget;
    signal->setColumnCount(2);
    signal->setHeaderLabels(QStringList() << "Name"<< "Address");

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(signal,0,0,10,8);
    mainLayout->addWidget(buttonView,10,10,1,1);
    setLayout(mainLayout);
}

LayoutTabMessage::LayoutTabMessage(const QString *s, QWidget *parent)
    : QWidget(parent)
{
    QTextEdit *CommentEdit = new QTextEdit(*s);
    QVBoxLayout *Layout = new QVBoxLayout;
    Layout->addWidget(CommentEdit);
    setLayout(Layout);
}

AttributesTabMessage::AttributesTabMessage(const QString *s, QWidget *parent)
    : QWidget(parent)
{
    QTextEdit *CommentEdit = new QTextEdit(*s);
    QVBoxLayout *Layout = new QVBoxLayout;
    Layout->addWidget(CommentEdit);
    setLayout(Layout);
}

CommentTabMessage::CommentTabMessage(const QString s, QWidget *parent)
    : QWidget(parent)
{
    QTextEdit *CommentEdit = new QTextEdit(s);
    QVBoxLayout *Layout = new QVBoxLayout;
    Layout->addWidget(CommentEdit);
    setLayout(Layout);
}
